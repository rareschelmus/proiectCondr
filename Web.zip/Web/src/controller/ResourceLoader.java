package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.digest.DigestUtils;

@WebServlet("/ResourceLoader")
public class ResourceLoader extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public ResourceLoader() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = (String) request.getParameter("v");
//		System.out.println(DigestUtils.sha256Hex("4"));
//		System.out.println(path);
		if (path.equals(DigestUtils.sha256Hex("2"))) {
			 //styles/main_page.css 2
			request.getRequestDispatcher("/styles/main_page.css").forward(request, response);
		} else 
		if (path.equals(DigestUtils.sha256Hex("3"))) {
			///bootstrap_social/bootstrap-social.css 3
			request.getRequestDispatcher("/bootstrap_social/bootstrap-social.css").forward(request, response);
		} else 
	    if (path.equals(DigestUtils.sha256Hex("4"))) {
				request.getRequestDispatcher("/styles/user_profile.css").forward(request, response);
	    } else 
		if (path.equals(DigestUtils.sha256Hex("5"))) {
		     request.getRequestDispatcher("/js/resources.js").forward(request, response);
		} 
	}

}
